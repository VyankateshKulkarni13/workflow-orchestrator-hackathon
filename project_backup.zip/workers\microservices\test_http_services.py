"""
test_http_services.py
---------------------
Tests all 3 HTTP microservices end-to-end.

Run AFTER starting all 3 services (see instructions below).

Usage:
    python test_http_services.py

No pytest needed — plain Python, no extra dependencies beyond `urllib`.
"""

import json
import sys
import urllib.request
import urllib.error

# ── Config ────────────────────────────────────────────────────────────────────
INVENTORY_BASE    = "http://localhost:8001"
ORDER_BASE        = "http://localhost:8002"
NOTIFICATION_BASE = "http://localhost:8003"

PASS = 0
FAIL = 0
SEP  = "─" * 60


# ── HTTP helpers ──────────────────────────────────────────────────────────────

def http_get(url: str) -> tuple[int, dict]:
    """Make a GET request, return (status_code, response_dict)."""
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            return resp.getcode(), json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = json.loads(e.read()) if e.fp else {}
        return e.code, body


def http_post(url: str, body: dict) -> tuple[int, dict]:
    """Make a POST request with JSON body, return (status_code, response_dict)."""
    data = json.dumps(body).encode("utf-8")
    req  = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.getcode(), json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = json.loads(e.read()) if e.fp else {}
        return e.code, body


def check(test_name: str, condition: bool, got=None, expected=None):
    """Print pass/fail and update counters."""
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  ✅ PASS  {test_name}")
    else:
        FAIL += 1
        print(f"  ❌ FAIL  {test_name}")
        if got is not None:
            print(f"          Got:      {got}")
        if expected is not None:
            print(f"          Expected: {expected}")


def section(title: str):
    print(f"\n{SEP}")
    print(f"  {title}")
    print(SEP)


# ── Pre-flight: check all services are up ────────────────────────────────────

def preflight():
    section("PRE-FLIGHT: Are all 3 services running?")
    all_ok = True
    for name, url in [
        ("Inventory Service  (port 8001)", f"{INVENTORY_BASE}/health"),
        ("Order Service      (port 8002)", f"{ORDER_BASE}/health"),
        ("Notification Svc   (port 8003)", f"{NOTIFICATION_BASE}/health"),
    ]:
        try:
            code, data = http_get(url)
            if code == 200:
                print(f"  ✅ {name} → UP")
            else:
                print(f"  ❌ {name} → HTTP {code}")
                all_ok = False
        except Exception as e:
            print(f"  ❌ {name} → NOT REACHABLE ({e})")
            all_ok = False

    if not all_ok:
        print("""
  ⛔ One or more services are NOT running. Start them first:

     Terminal 1:  python inventory_service.py
     Terminal 2:  python order_service.py
     Terminal 3:  python notification_service.py

  Then re-run this test script.
""")
        sys.exit(1)
    print()


# ════════════════════════════════════════════════════════════════
# INVENTORY SERVICE TESTS
# ════════════════════════════════════════════════════════════════

def test_inventory():
    section("INVENTORY SERVICE  — http://localhost:8001")

    # Test 1: item in stock
    code, data = http_get(f"{INVENTORY_BASE}/inventory/check?product_id=ITEM-001&quantity=2")
    check("In-stock item → HTTP 200",        code == 200)
    check("available = True",                data.get("available") is True,  data.get("available"), True)
    check("stock_left is an int",            isinstance(data.get("stock_left"), int))
    check("product_id echoed back",          data.get("product_id") == "ITEM-001")

    # Test 2: out of stock (ITEM-002 has 0 stock)
    code, data = http_get(f"{INVENTORY_BASE}/inventory/check?product_id=ITEM-002&quantity=1")
    check("Out-of-stock → HTTP 409",         code == 409)
    check("detail.available = False",        data.get("detail", {}).get("available") is False)
    check("error = OUT_OF_STOCK",            data.get("detail", {}).get("error") == "OUT_OF_STOCK")

    # Test 3: product not in catalogue
    code, data = http_get(f"{INVENTORY_BASE}/inventory/check?product_id=FAKE-999&quantity=1")
    check("Unknown product → HTTP 404",      code == 404)
    check("error = PRODUCT_NOT_FOUND",       data.get("detail", {}).get("error") == "PRODUCT_NOT_FOUND")

    # Test 4: spec example (prod_123)
    code, data = http_get(f"{INVENTORY_BASE}/inventory/check?product_id=prod_123&quantity=1")
    check("Spec example prod_123 → HTTP 200", code == 200)
    check("prod_123 available",              data.get("available") is True)

    # Test 5: invalid quantity (0)
    code, data = http_get(f"{INVENTORY_BASE}/inventory/check?product_id=ITEM-001&quantity=0")
    check("quantity=0 → HTTP 422 (validation)", code == 422)

    # Test 6: stock view admin endpoint
    code, data = http_get(f"{INVENTORY_BASE}/inventory/stock")
    check("Admin /stock → HTTP 200",         code == 200)
    check("Stock is a dict",                 isinstance(data.get("stock"), dict))


# ════════════════════════════════════════════════════════════════
# ORDER SERVICE TESTS
# ════════════════════════════════════════════════════════════════

def test_orders():
    section("ORDER SERVICE  — http://localhost:8002")

    # Test 1: create order — spec example
    code, data = http_post(f"{ORDER_BASE}/orders/create", {
        "customer_id": "cust_99",
        "product_id":  "prod_123",
    })
    check("Create order → HTTP 201",          code == 201)
    check("order_id returned",                "order_id" in data)
    check("status = CONFIRMED",               data.get("status") == "CONFIRMED")
    check("confirmation_code returned",       "confirmation_code" in data)

    created_order_id = data.get("order_id", "")

    # Test 2: update status CONFIRMED → PROCESSING
    code, data2 = http_post(f"{ORDER_BASE}/orders/update", {
        "order_id": created_order_id,
        "status":   "PROCESSING",
    })
    check("Update CONFIRMED→PROCESSING → HTTP 200",  code == 200)
    check("success = True",                          data2.get("success") is True)
    check("updated_at returned",                     "updated_at" in data2)
    check("new_status = PROCESSING",                 data2.get("new_status") == "PROCESSING")

    # Test 3: update to COMPLETED (via PROCESSING → COMPLETED)
    code, data3 = http_post(f"{ORDER_BASE}/orders/update", {
        "order_id": created_order_id,
        "status":   "COMPLETED",
    })
    check("Update PROCESSING→COMPLETED → HTTP 200",  code == 200)
    check("new_status = COMPLETED",                  data3.get("new_status") == "COMPLETED")

    # Test 4: invalid status transition (COMPLETED → CONFIRMED not allowed)
    code, data4 = http_post(f"{ORDER_BASE}/orders/update", {
        "order_id": created_order_id,
        "status":   "CONFIRMED",
    })
    check("Invalid transition → HTTP 422",           code == 422)
    check("error = INVALID_STATUS_TRANSITION",       data4.get("detail", {}).get("error") == "INVALID_STATUS_TRANSITION")

    # Test 5: update non-existent order
    code, data5 = http_post(f"{ORDER_BASE}/orders/update", {
        "order_id": "ord_DOESNOTEXIST",
        "status":   "PROCESSING",
    })
    check("Unknown order → HTTP 404",                code == 404)
    check("error = ORDER_NOT_FOUND",                 data5.get("detail", {}).get("error") == "ORDER_NOT_FOUND")

    # Test 6: missing customer_id
    code, data6 = http_post(f"{ORDER_BASE}/orders/create", {
        "product_id": "prod_123",
    })
    check("Missing customer_id → HTTP 422",          code == 422)

    # Test 7: list orders
    code, data7 = http_get(f"{ORDER_BASE}/orders")
    check("Admin /orders → HTTP 200",                code == 200)
    check("total >= 1",                              data7.get("total", 0) >= 1)


# ════════════════════════════════════════════════════════════════
# NOTIFICATION SERVICE TESTS
# ════════════════════════════════════════════════════════════════

def test_notifications():
    section("NOTIFICATION SERVICE  — http://localhost:8003")

    # Test 1: email — spec example
    code, data = http_post(f"{NOTIFICATION_BASE}/notifications/send", {
        "channel": "email",
        "payload": {"message": "Order confirmed!", "to": "user@example.com"},
    })
    check("Email notification → HTTP 200",    code == 200)
    check("delivered = True",                data.get("delivered") is True)
    check("timestamp returned",              "timestamp" in data)
    check("notification_id returned",        "notification_id" in data)
    check("channel = email",                 data.get("channel") == "email")

    # Test 2: mock channel
    code, data2 = http_post(f"{NOTIFICATION_BASE}/notifications/send", {
        "channel": "mock",
        "payload": {"message": "Test!"},
        "order_id": "ord_test_001",
    })
    check("Mock channel → HTTP 200",          code == 200)
    check("delivered = True",                data2.get("delivered") is True)

    # Test 3: SMS channel
    code, data3 = http_post(f"{NOTIFICATION_BASE}/notifications/send", {
        "channel": "sms",
        "payload": {"message": "Your order shipped!", "to": "+1234567890"},
    })
    check("SMS channel → HTTP 200",           code == 200)

    # Test 4: unsupported channel
    code, data4 = http_post(f"{NOTIFICATION_BASE}/notifications/send", {
        "channel": "fax",
        "payload": {"message": "Hello from 1995"},
    })
    check("Unsupported channel → HTTP 400",  code == 400)
    check("error = UNSUPPORTED_CHANNEL",     data4.get("detail", {}).get("error") == "UNSUPPORTED_CHANNEL")

    # Test 5: missing channel field
    code, data5 = http_post(f"{NOTIFICATION_BASE}/notifications/send", {
        "payload": {"message": "No channel set"},
    })
    check("Missing channel → HTTP 422",      code == 422)

    # Test 6: notification log
    code, data6 = http_get(f"{NOTIFICATION_BASE}/notifications/log")
    check("Admin /log → HTTP 200",           code == 200)
    check("total >= 1",                      data6.get("total", 0) >= 1)


# ════════════════════════════════════════════════════════════════
# FULL END-TO-END WORKFLOW TEST
# ════════════════════════════════════════════════════════════════

def test_full_workflow():
    section("🔁 FULL END-TO-END WORKFLOW (simulates Orchestrator)")

    print("  Simulating: Start → Inventory → Order DB → Notifications\n")

    # ── Step 1: Check Inventory ───────────────────────────────────────────────
    print("  [Step 1] Calling Inventory Service…")
    code, inv = http_get(f"{INVENTORY_BASE}/inventory/check?product_id=ITEM-004&quantity=1")
    check("Step 1 — Inventory check succeeded", code == 200 and inv.get("available") is True)
    if code != 200:
        print("  ⛔ Inventory failed — workflow stops here")
        return

    # ── Step 2: Create Order ──────────────────────────────────────────────────
    print("  [Step 2] Calling Order Service /create…")
    code, order = http_post(f"{ORDER_BASE}/orders/create", {
        "customer_id":  "cust_e2e_001",
        "product_id":   "ITEM-004",
        "quantity":     1,
        "total_amount": 49.99,
        "currency":     "USD",
    })
    check("Step 2 — Order created", code == 201 and "order_id" in order)
    if code != 201:
        print("  ⛔ Order creation failed — workflow stops here")
        return
    order_id = order["order_id"]
    print(f"          order_id = {order_id}")

    # ── Step 3: Update Order Status ───────────────────────────────────────────
    print("  [Step 3] Calling Order Service /update → PROCESSING…")
    code, upd = http_post(f"{ORDER_BASE}/orders/update", {
        "order_id": order_id,
        "status":   "PROCESSING",
    })
    check("Step 3 — Status → PROCESSING", code == 200 and upd.get("success") is True)

    # ── Step 4: Send Notification ─────────────────────────────────────────────
    print("  [Step 4] Calling Notification Service → email…")
    code, notif = http_post(f"{NOTIFICATION_BASE}/notifications/send", {
        "channel":   "email",
        "payload": {
            "to":      "customer@example.com",
            "subject": f"Order {order_id} Confirmed",
            "message": f"Your order {order_id} is being processed.",
        },
        "order_id": order_id,
    })
    check("Step 4 — Email notification sent", code == 200 and notif.get("delivered") is True)

    # ── Step 5: Mark complete ─────────────────────────────────────────────────
    print("  [Step 5] Calling Order Service /update → COMPLETED…")
    code, done = http_post(f"{ORDER_BASE}/orders/update", {
        "order_id": order_id,
        "status":   "COMPLETED",
    })
    check("Step 5 — Status → COMPLETED", code == 200 and done.get("success") is True)

    if FAIL == 0:
        print(f"\n  🎉 Full end-to-end workflow completed successfully!")
    print()


# ════════════════════════════════════════════════════════════════
# SUMMARY
# ════════════════════════════════════════════════════════════════

def summary():
    section("TEST SUMMARY")
    total = PASS + FAIL
    print(f"  Passed: {PASS}/{total}")
    print(f"  Failed: {FAIL}/{total}")
    if FAIL == 0:
        print("\n  🎉 ALL TESTS PASSED!")
    else:
        print(f"\n  ⚠️  {FAIL} test(s) failed — check output above.")
    print()


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n" + "═" * 60)
    print("  HTTP MICROSERVICES — FULL TEST SUITE")
    print("  Inventory (8001) · Orders (8002) · Notifications (8003)")
    print("═" * 60)

    preflight()
    test_inventory()
    test_orders()
    test_notifications()
    test_full_workflow()
    summary()
